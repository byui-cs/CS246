package journal;

import org.w3c.dom.Element;

/**
 * Holds a topic, which at this point simply has a name.
 * @author sburton
 */
public class Topic implements Annotation {
    private String name;
    
    public static final String XML_ATTRIBUTE_NAME = "name";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * Loads the name if present
     * @param element 
     */
    void loadFromXml(Element element) {
        if (element.hasAttribute(XML_ATTRIBUTE_NAME)) {
            name = element.getAttribute(XML_ATTRIBUTE_NAME);
        } else {
            name = element.getTextContent().trim();
        }
    }

    /**
     * Gets the display text of a topic
     * @return 
     */
    @Override
    public String getDisplayText() {
        return name;
    }
    
    @Override
    public String toString() {
        return getDisplayText();
    }
        
}
