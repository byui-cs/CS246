package journal;

import org.w3c.dom.Element;

/**
 * Holds a Scripture (book, chapter, start/end verses)
 * @author Br. Burton
 */
public class Scripture implements Annotation {
    private String book = "";
    private int chapter = NONE;
    private int startVerse = NONE;
    private int endVerse = NONE;
    
    public static final int NONE = -1;
    
    public static final String XML_ATTRIBUTE_BOOK = "book";
    public static final String XML_ATTRIBUTE_CHAPTER = "chapter";
    
    // Note that in the instructions on I-Learn this was "startVerse"
    // but in the example XML file, it was "startverse" lowercase v.
    public static final String XML_ATTRIBUTE_START_VERSE = "startverse";
    public static final String XML_ATTRIBUTE_END_VERSE = "endverse";

    public String getBook() {
        return book;
    }

    public void setBook(String book) {
        this.book = book;
    }

    public int getChapter() {
        return chapter;
    }

    public void setChapter(int chapter) {
        this.chapter = chapter;
    }

    public int getStartVerse() {
        return startVerse;
    }

    public void setStartVerse(int startVerse) {
        this.startVerse = startVerse;
    }

    public int getEndVerse() {
        return endVerse;
    }

    public void setEndVerse(int endVerse) {
        this.endVerse = endVerse;
    }

    /**
     * Loads the book, chapter, startVerse, and endVerse if present.
     * @param element 
     */
    void loadFromXml(Element element) {
        if (element.hasAttribute(XML_ATTRIBUTE_BOOK)) {
            book = element.getAttribute(XML_ATTRIBUTE_BOOK);
        }
        
        if (element.hasAttribute(XML_ATTRIBUTE_CHAPTER)) {
            chapter = Integer.parseInt(element.getAttribute(XML_ATTRIBUTE_CHAPTER));
        }
        
        if (element.hasAttribute(XML_ATTRIBUTE_START_VERSE)) {
            startVerse = Integer.parseInt(element.getAttribute(XML_ATTRIBUTE_START_VERSE));
        }
        
        if (element.hasAttribute(XML_ATTRIBUTE_END_VERSE)) {
            endVerse = Integer.parseInt(element.getAttribute(XML_ATTRIBUTE_END_VERSE));
        }
    }

    /**
     * Gets the display text of a scripture, such as: "John 3:16"
     * @return 
     */
    @Override
    public String getDisplayText() {
        StringBuilder builder = new StringBuilder();
        builder.append(book);
        
        if (chapter != NONE) {
            builder.append(" ").append(chapter);
            
            if (startVerse != NONE) {
                builder.append(":").append(startVerse);
                
                if (endVerse != NONE) {
                    builder.append("-").append(endVerse);
                }
            }
        }
        
        return builder.toString();
    }
    
    @Override
    public String toString() {
        return getDisplayText();
    }
    
}
