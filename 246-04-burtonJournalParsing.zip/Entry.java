package journal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Represents an individual journal entry (its date, content, and annotations)
 * @author Br. Burton
 */
public class Entry {
    private List<Annotation> annotations;
    private String date; // This could be improved by using an actual date object
    private String content;
    
    public static final String XML_ATTRIBUTE_DATE = "date";
    public static final String XML_ELEMENT_SCRIPTURE = "scripture";
    public static final String XML_ELEMENT_TOPIC = "topic";
    public static final String XML_ELEMENT_CONTENT = "content";
    
    public Entry() {
        annotations = new ArrayList<>();
    }

    public List<Annotation> getAnnotations() {
        return annotations;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
    
    /**
     * Displays an entry, including the date, content, and each annotation.
     */
    public void display() {
        System.out.println("-----");
        System.out.println("Entry");
        System.out.println("Date: " + date);
        System.out.println();
        
        System.out.println("Content:");
        System.out.println(content);
        System.out.println();
        
        System.out.println("Annotations:");
        for (Annotation annotation : annotations) {
            System.out.println("  - " + annotation.getDisplayText());
        }
        
        System.out.println();
    }

    /**
     * Loads an entry (and its content and annotations) from an XML element.
     * @param element The entry element.
     */
    public void loadFromXml(Element element) {

        if (element.hasAttribute(XML_ATTRIBUTE_DATE)) {
            date = element.getAttribute(XML_ATTRIBUTE_DATE);
        }
        
        NodeList childNodes = element.getChildNodes();
        
        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);
            
            // Ensure that we have an actual element (not just text, etc.)
            if (childNode.getNodeType() == Node.ELEMENT_NODE) {
                
                try {
                    loadChildNode((Element) childNode);
                } catch (Exception ex) {
                    // Ideally this would be in a log file
                    System.out.println("Error loading entry child node. It will be skipped.");
                    System.out.println("Details: " + ex.getMessage());
                }
            }
        }
    }
    
    /**
     * Loads the child node appropriately. This is essentially a factory method
     * for creating Scriptures and Topics, but also handles content.
     * 
     * @param child The child element to load (e.g., a Scripture, Topic, Content)
     * @throws IOException if an unexpected child is encountered
     */
    private void loadChildNode(Element child) throws IOException {
        switch (child.getNodeName()) {
            case XML_ELEMENT_CONTENT:
                content = child.getTextContent();
                
                // This wasn't required, but we could strip whitespace around the newlines
                content = stripWhiteSpace(content);
                break;
                
            case XML_ELEMENT_SCRIPTURE:
                Scripture scripture = new Scripture();
                scripture.loadFromXml(child);
                
                annotations.add(scripture);
                break;
                
            case XML_ELEMENT_TOPIC:
                Topic topic = new Topic();
                topic.loadFromXml(child);
                
                annotations.add(topic);
                break;
                
            default:
                throw new IOException("Unexpected child of Entry: " + child.getNodeName());
        }
    }
    
    /**
     * Removes leading and trailing whitespace, as well as any before/after newlines.
     * @param content
     * @return The string with whitespace removed
     */
    private String stripWhiteSpace(String content) {
        String clean = content.trim();
        clean = clean.replaceAll("\\s*\\n\\s*", "\n");
        
        return clean;
    }   
}
