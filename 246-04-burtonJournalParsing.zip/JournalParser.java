package journal;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

/**
 * The main class used to open an XML file and load a journal from it.
 * @author Br. Burton
 */
public class JournalParser {
    
    public static final String XML_ELEMENT_JOURNAL = "journal";
    
    /**
     * The main entry point for the program.
     * @param args Expects one argument, the name of the XML file to load.
     */
    public static void main(String[] args) {
        if (args.length == 1) {
            String xmlFile = args[0];
            new JournalParser().run(xmlFile);
        } else {
            System.out.println("Incorrect commandline parameters.");
            System.out.println("Expects a single parameter representing the xml file to load.");
        }
    }
    
    /**
     * Loads a journal from the given XML file and display it.
     * @param xmlFile The XML file containing the journal
     */
    public void run(String xmlFile) {
        try {
            Journal journal = loadFromFile(xmlFile);
            journal.display();
            
        } catch(Exception ex) {
            // Ideally we would sent this to a log file, rather than just display it.
            System.out.println("Error parsing journal. Details: " + ex.getMessage());
        }
    }

    /**
     * Opens the XML file and loads a journal from it.
     * @param xmlFile
     * @return The journal, fully loaded.
     * @throws IOException
     * @throws ParserConfigurationException
     * @throws SAXException 
     */
    private Journal loadFromFile(String xmlFile) throws IOException,
            ParserConfigurationException, SAXException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        
        Document document = builder.parse(new File(xmlFile));
        Node journalNode = document.getDocumentElement();
        
        //optional, but recommended
	// see - http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
        journalNode.normalize();
        
        // Ensure that we have the correct root node
        if (!journalNode.getNodeName().equals(XML_ELEMENT_JOURNAL)) {
            throw new IOException("Error: The document element should have been: "
                    + XML_ELEMENT_JOURNAL + " but was: " + journalNode.getNodeName());
        }
        
        Journal journal = new Journal();
        journal.loadFromXml(journalNode);
        
        return journal;
    }
}
