package journal;

import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Represents the complete Journal which is a list of Entry objects.
 * @author Br. Burton
 */
public class Journal {
    private List<Entry> entries;
    
    public Journal() {
        entries = new ArrayList<>();
    }
    
    List<Entry> getEntries() {
        return entries;
    }
    
    /**
     * Adds an entry to the list
     * @param entry 
     */
    public void addEntry(Entry entry) {
        entries.add(entry);
    }
    
    /**
     * Displays a journal by displaying each entry
     */
    void display() {
        for (Entry entry : entries) {
            entry.display();
        }
    }

    /**
     * Loads a journal (and all of its entries) from an XML node.
     * @param journalNode 
     */
    void loadFromXml(Node journalNode) {
        NodeList entryNodes = journalNode.getChildNodes();
        
        for (int i = 0; i < entryNodes.getLength(); i++) {
            Node entryNode = entryNodes.item(i);
            
            // skip any nodes that are just text or comments, etc.
            if (entryNode.getNodeType() == Node.ELEMENT_NODE) {
                // now that we are sure it is an element, we can cast it as such
                Entry entry = new Entry();
                entry.loadFromXml((Element) entryNode);
                
                entries.add(entry);
            }
        }
    }
    
}
