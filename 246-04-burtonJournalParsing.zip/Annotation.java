package journal;

/**
 * Defines an Annotation which must simply have display text.
 * @author Br. Burton
 */
public interface Annotation {
    /**
     * Gets the text that should be displayed to the user to represent this
     * annotation.
     * @return 
     */
    public String getDisplayText();
    
}
